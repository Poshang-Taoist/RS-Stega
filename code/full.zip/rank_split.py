import torch
from typing import List
import numpy as np

def text_to_bits(text: str) -> List[int]:
    """
    Convert each character in 'text' to its 8-bit binary form.
    Returns a list of bits (0 or 1).
    """
    bits = []
    for ch in text:
        bin_repr = format(ord(ch), '08b')
        bits.extend(int(bit) for bit in bin_repr)
    return bits


def bits_to_text(bits: List[int]) -> str:
    """
    Convert a list of bits into a text string, interpreting every 8 bits as one character.
    Ignore incomplete final 8-bit chunks if any remain.
    """
    chars = []
    for i in range(0, len(bits), 8):
        byte_bits = bits[i:i + 8]
        if len(byte_bits) < 8:
            break
        byte_val = int(''.join(str(b) for b in byte_bits), 2)
        chars.append(chr(byte_val))
    return ''.join(chars)


def bits2int(bit_list: List[int]) -> int:
    """
    Convert a list of bits (most significant bit first) to an integer.
    E.g., [1,0,1] -> 5
    """
    value = 0
    for bit in bit_list:
        value = (value << 1) | bit
    return value


def int2bits(value: int, width: int) -> List[int]:
    """
    Convert an integer 'value' to a list of bits of length 'width' (MSB first).
    E.g., (5,3) -> [1,0,1]
    """
    return [(value >> i) & 1 for i in reversed(range(width))]


class RankStatic:
    """
    An index-based (or rank-based) steganography approach using a language model.

    At each step:
      - Get the model's top-k tokens by probability.
      - Interpret 'bits_per_step' bits from the secret message as an integer idx in [0, k-1].
      - Pick the idx-th token in the sorted top-k list.
      - Decoding sees which rank was chosen to recover those bits.
    """

    def __init__(self, model, tokenizer, #collector,
                 bits_per_step: int, topk: int = None,
                 threshold=None,
                 temperature: float = 1.0, device: str = 'cpu'):
        """
        Args:
            model: A language model from Hugging Face (e.g. GPT-2).
            tokenizer: Paired tokenizer.
            bits_per_step: Number of bits to embed per token generation step.
            topk: Number of tokens we consider each step (must be >= 2^bits_per_step).
                  If None, we set topk = 2^bits_per_step exactly.
            temperature: Softmax temperature for next-token probabilities.
            device: 'cpu' or 'cuda'.
        """
        self.model = model.to(device)
        self.tokenizer = tokenizer
        # self.collector = collector
        self.bits_per_step = bits_per_step // 2
        if topk is None:
            self.topk = 2 ** bits_per_step
        else:
            self.topk = topk
        self.temperature = temperature
        self.device = device
        self.threshold = threshold
        self.log_list = [] 


    def encode(self, message_bits: List[int], prompt: str) -> (str, List[int]):
        # Convert prompt to token IDs
        input_ids = torch.tensor(self.tokenizer.encode(prompt), device=self.device).unsqueeze(0)
        output_ids = input_ids.clone()

        bit_idx = 0
        total_bits = len(message_bits)
        i = 0

        while bit_idx < total_bits:
            with torch.no_grad():
                outputs = self.model(output_ids)
                logits = outputs.logits[:, -1, :]  # shape: (1, vocab_size)

            # Apply temperature
            logits = logits / self.temperature
            sorted_logits, sorted_indices = torch.sort(logits, descending=True)
            sorted_probs = torch.softmax(sorted_logits, dim=-1).squeeze(0)

            # Take next bits
            bits_needed = self.bits_per_step
            if bit_idx + bits_needed > total_bits:
                bits_needed = total_bits - bit_idx
            chunk_bits = message_bits[bit_idx: bit_idx + bits_needed]
            bit_idx += bits_needed

            # If we got fewer bits than bits_per_step, pad with zeros
            if len(chunk_bits) < self.bits_per_step:
                chunk_bits += [0] * (self.bits_per_step - len(chunk_bits))

            idx = bits2int(chunk_bits)  # integer in [0, 2^bits_per_step - 1]

            # Record the experiment step (if collector is provided)
            token_prob = sorted_probs[idx]
            self.log_list.append(token_prob)

            chosen_token_id = sorted_indices[0, idx].unsqueeze(0).unsqueeze(0)  # shape: (1,1)
            output_ids = torch.cat([output_ids, chosen_token_id], dim=-1)
            i += 1

        cover_text = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
        return cover_text, output_ids[0].tolist(), self.calculate_ppl(), total_bits / i

    def calculate_ppl(self):
        log_probs = torch.log(torch.tensor(self.log_list, device=self.device))  # 在 CUDA 上取对数
        avg_log_prob = torch.mean(log_probs)  # 计算平均 log 概率
        ppl = torch.exp(-avg_log_prob)  # 计算 PPL
        return ppl.item()  # 转换为 Python float

    def decode(self, cover_ids: List[int], prompt: str, max_bits=10_000) -> List[int]:
        # Identify the portion beyond the prompt
        prompt_ids = self.tokenizer.encode(prompt)
        generated_ids = cover_ids[len(prompt_ids):]

        recovered_bits = []

        # We'll reconstruct the model input step by step
        output_ids = torch.tensor(prompt_ids, device=self.device).unsqueeze(0)

        for token_id in generated_ids:
            with torch.no_grad():
                outputs = self.model(output_ids)
                logits = outputs.logits[:, -1, :]

            logits = logits / self.temperature
            top_logits, top_indices = torch.topk(logits, k=self.topk, dim=-1)

            # Find which rank among top-k matches 'token_id'
            try:
                rank = (top_indices[0] == token_id).nonzero(as_tuple=True)[0].item()
            except:
                # If not found in top-k, fallback to 0
                rank = 0

            # Convert rank to bits
            rank_bits = int2bits(rank, self.bits_per_step)

            # Append bits, but stop if we exceed max_bits
            for b in rank_bits:
                if len(recovered_bits) < max_bits:
                    recovered_bits.append(b)
                else:
                    break

            # Update output_ids with the actual chosen token
            chosen_id = torch.tensor([[token_id]], device=self.device)
            output_ids = torch.cat([output_ids, chosen_id], dim=-1)

            if len(recovered_bits) >= max_bits:
                break

        return recovered_bits


if __name__ == "__main__":
    from transformers import GPT2LMHeadModel, GPT2Tokenizer
    from global_var import path
    
    # 1) Setup
    tokenizer = GPT2Tokenizer.from_pretrained(path)
    model = GPT2LMHeadModel.from_pretrained(path)

    # Let's say we want to embed 3 bits per token => topk=8
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    stego = RankStatic(model, tokenizer, 
                       bits_per_step=4, #topk=16,
                       temperature=1.0, device=device)

    # 2) Prepare message and prompt
    secret_message = "Hello Rank-based Steganography!"
    message_bits = text_to_bits(secret_message)
    prompt = "Hello, I'm a language model."

    # 3) Encode
    cover_text, cover_ids, ppl, bpw = stego.encode(message_bits, prompt)
    print("[Cover text]:", cover_text)

    print(f"Bits per word: {bpw}")
    print(f"PPL: {ppl}")

    # 4) Decode
    # recovered_bits  = stego.decode(cover_ids, prompt, max_bits=100000)
    # recovered_text = bits_to_text(recovered_bits)
    # print("[Recovered text]:", recovered_text)
