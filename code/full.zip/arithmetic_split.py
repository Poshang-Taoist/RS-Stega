import torch
import torch.nn.functional as F
import numpy as np
from transformers import GPT2LMHeadModel, GPT2Tokenizer


def bits2int(bits: list) -> int:
    """Convert a list of bits (MSB first) to an integer."""
    value = 0
    for bit in bits:
        value = (value << 1) | bit
    return value


def int2bits(x: int, precision: int) -> list:
    """Convert an integer x into a list of bits (MSB first) of length 'precision'."""
    bits = []
    for i in range(precision - 1, -1, -1):
        bits.append((x >> i) & 1)
    return bits


def num_same_from_beg(a: list, b: list) -> int:
    """Return the number of identical bits from the beginning of lists a and b."""
    n = min(len(a), len(b))
    count = 0
    for i in range(n):
        if a[i] == b[i]:
            count += 1
        else:
            break
    return count


class ArithmeticSteganography:
    """
    A toy example of arithmetic steganography using integer‐based arithmetic coding.

    In this version:
      - The secret message (a list of bits) is viewed as an integer in [0, 2^precision).
      - The current interval [L, H) is initialized to [0, 2^precision) and is updated at each step.
      - The language model (GPT‑2) provides a probability distribution (restricted to top_k tokens).
      - Candidate probabilities are scaled to the current interval (via integer “masses”).
      - A block of secret bits (of length precision) is used to choose a candidate whose cumulative
        integer mass “covers” the secret integer.
      - The interval is updated by determining how many of the most‐significant bits are fixed.

    This encoder keeps generating tokens until all the secret bits are embedded.
    The decoder processes all generated tokens to recover the secret.
    """

    def __init__(self, model, tokenizer, device: str = 'cpu', precision: int = 16, top_k: int = 16):
        self.model = model.to(device)
        self.tokenizer = tokenizer
        self.device = device
        self.precision = precision
        self.top_k = top_k
        self.log_list = []

    def encode(self, message_bits: list, prompt: str) -> (str, list):
        """
        Encode the binary message into cover text using integer-based arithmetic encoding.
        This version runs until all secret bits are embedded.

        Args:
            message_bits (list): The secret message as a list of bits.
            prompt (str): The initial prompt/context.

        Returns:
            cover_text (str): The generated text that embeds the secret message.
            cover_ids (list): The token IDs of the generated text (including the prompt).
        """
        max_val = 2 ** (self.precision//2)
        # Initialize current interval [L, H)
        L = 0
        H = max_val

        secret_ptr = 0  # pointer into message_bits
        total_secret_bits = len(message_bits)

        input_ids = torch.tensor(self.tokenizer.encode(prompt), device=self.device).unsqueeze(0)
        output_ids = input_ids.clone()
        prev_ids = input_ids.clone()    
        step = 0

        while secret_ptr < total_secret_bits:
            # print(f"\n=== Encoding step {step + 1} ===")
            # print(f"Current interval: [{L}, {H})")
            cur_range = H - L
            # print(f"Current range (width): {cur_range}")

            # Get LM output for the current context.
            with torch.no_grad():
                outputs = self.model(prev_ids)
                logits = outputs.logits[:, -1, :]

            # Restrict to top_k tokens.
            top_logits, top_indices = torch.topk(logits, k=self.top_k, dim=-1)
            probs = F.softmax(top_logits, dim=-1).squeeze(0).cpu().numpy()

            # Scale candidate probabilities to integer masses over the current range.
            int_masses = []
            for p in probs:
                mass = round(p * cur_range)
                int_masses.append(mass)
            # Adjust if rounding does not sum to cur_range.
            mass_sum = sum(int_masses)
            if mass_sum != cur_range:
                int_masses[-1] += (cur_range - mass_sum)

            # Compute cumulative masses.
            cum_masses = []
            cum = 0
            for mass in int_masses:
                cum += mass
                cum_masses.append(cum)
            # The candidate intervals are [L + previous mass, L + current cumulative mass).
            cum_intervals = [L + cm for cm in cum_masses]

            # print("Candidate tokens and their integer intervals:")
            # prev = L
            # for i, (token_id, mass, cum_val) in enumerate(zip(top_indices[0].tolist(), int_masses, cum_intervals)):
            #     token_str = self.tokenizer.decode([token_id]).strip()
            #     interval_low = prev
            #     interval_high = cum_val
            #     # print(
            #     #     f"  Candidate {i}: token_id={token_id}, token='{token_str}', mass={mass}, interval=[{interval_low}, {interval_high})")
            #     prev = cum_val

            # Extract the next block of 'precision' secret bits (pad with zeros if necessary)
            secret_slice = message_bits[secret_ptr: secret_ptr + self.precision//2]
            if len(secret_slice) < self.precision//2:
                secret_slice = secret_slice + [0] * (self.precision//2 - len(secret_slice))
            secret_int = bits2int(secret_slice)
            # print(f"Secret bits (from position {secret_ptr}): {secret_slice} -> integer value: {secret_int}")

            # Choose candidate: the first candidate whose cumulative interval exceeds secret_int.
            selection = None
            for i, interval_val in enumerate(cum_intervals):
                if secret_int < interval_val:
                    selection = i
                    # print(f"--> Secret integer {secret_int} falls in candidate {i} interval.")
                    break
            if selection is None:
                selection = 0
                # print("No candidate found; defaulting to candidate 0.")

            # Update interval to that of the selected candidate.
            new_L = L if selection == 0 else cum_intervals[selection - 1]
            new_H = cum_intervals[selection]
            # print(f"Selected candidate {selection} with new interval: [{new_L}, {new_H})")

            # Determine how many most-significant bits become fixed.
            new_L_bits = int2bits(new_L, self.precision//2)
            new_H_bits = int2bits(new_H - 1, self.precision//2)  # new_H is exclusive
            num_fixed = num_same_from_beg(new_L_bits, new_H_bits)
            # print(f"Common fixed bits: {num_fixed} bits")
            secret_ptr += num_fixed
            # print(f"Updated secret pointer: {secret_ptr} / {total_secret_bits}")

            # Update the interval by removing the fixed bits.
            unfixed_L_bits = new_L_bits[num_fixed:] if num_fixed < self.precision//2 else []
            unfixed_H_bits = new_H_bits[num_fixed:] if num_fixed < self.precision//2 else []
            # Pad the unfixed part back to length 'precision'
            new_L_bits_updated = unfixed_L_bits + [0] * num_fixed
            new_H_bits_updated = unfixed_H_bits + [1] * num_fixed
            L = bits2int(new_L_bits_updated)
            H = bits2int(new_H_bits_updated) + 1  # H is exclusive
            # print(f"Updated interval for next step: [{L}, {H})")

            # Append the chosen token to the output.
            chosen_prob = probs[selection]  # 选择的 token 的概率
            self.log_list.append(chosen_prob)  # 记录概率
            chosen_token_id = top_indices[0, selection].unsqueeze(0).unsqueeze(0)
            output_ids = torch.cat([output_ids, chosen_token_id], dim=-1)
            prev_ids = output_ids[-512:]#
            step += 1

        bpw = self.calculate_bpw(len(message_bits), step)
        ppl = self.calculate_ppl()
        cover_text = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
        return cover_text, output_ids[0].tolist(), bpw, ppl

    def calculate_ppl(self):
        log_probs = np.log(self.log_list)  # 取对数
        avg_log_prob = np.mean(log_probs)  # 计算平均 log 概率
        ppl = np.exp(-avg_log_prob)  # 计算 PPL
        return ppl
    def calculate_bpw(self, num_bits, num_generated_tokens):
        bpw = num_bits / num_generated_tokens if num_generated_tokens > 0 else 0
        return bpw

    def decode(self, cover_ids: list, prompt: str) -> list:
        """
        Decode the secret binary message from the cover text using integer-based arithmetic decoding.
        This version runs through all generated tokens until completion.

        Args:
            cover_ids (list): Token IDs of the cover text (including the prompt).
            prompt (str): The prompt used during encoding.

        Returns:
            message_bits (list): The recovered secret bits.
        """
        max_val = 2 ** self.precision
        L = 0
        H = max_val

        prompt_ids = self.tokenizer.encode(prompt)
        generated_ids = cover_ids[len(prompt_ids):]
        output_ids = torch.tensor(prompt_ids, device=self.device).unsqueeze(0)

        recovered_bits = []

        for step, token_id in enumerate(generated_ids):
            # print(f"\n=== Decoding step {step + 1} ===")
            # print(f"Current interval: [{L}, {H})")
            cur_range = H - L
            # print(f"Current range: {cur_range}")

            with torch.no_grad():
                outputs = self.model(output_ids)
                logits = outputs.logits[:, -1, :]

            top_logits, top_indices = torch.topk(logits, k=self.top_k, dim=-1)
            probs = F.softmax(top_logits, dim=-1).squeeze(0).cpu().numpy()

            int_masses = []
            for p in probs:
                mass = round(p * cur_range)
                int_masses.append(mass)
            mass_sum = sum(int_masses)
            if mass_sum != cur_range:
                int_masses[-1] += (cur_range - mass_sum)

            cum_masses = []
            cum = 0
            for mass in int_masses:
                cum += mass
                cum_masses.append(cum)
            cum_intervals = [L + cm for cm in cum_masses]

            # print("Candidate tokens and their integer intervals:")
            prev = L
            candidate_index = None
            for i, (tid, mass, cum_val) in enumerate(zip(top_indices[0].tolist(), int_masses, cum_intervals)):
                token_str = self.tokenizer.decode([tid]).strip()
                interval_low = prev
                interval_high = cum_val
                # print(
                #     f"  Candidate {i}: token_id={tid}, token='{token_str}', mass={mass}, interval=[{interval_low}, {interval_high})")
                if tid == token_id:
                    candidate_index = i
                    # print(f"--> Found matching token at candidate {i}.")
                prev = cum_val

            if candidate_index is None:
                candidate_index = 0
                # print("No matching candidate found; defaulting to candidate 0.")

            new_L = L if candidate_index == 0 else cum_intervals[candidate_index - 1]
            new_H = cum_intervals[candidate_index]
            # print(f"Selected candidate {candidate_index} with new interval: [{new_L}, {new_H})")

            new_L_bits = int2bits(new_L, self.precision)
            new_H_bits = int2bits(new_H - 1, self.precision)
            num_fixed = num_same_from_beg(new_L_bits, new_H_bits)
            # print(f"Common fixed bits: {num_fixed} bits")
            fixed_bits = new_L_bits[:num_fixed]
            recovered_bits.extend(fixed_bits)
            # print(f"Recovered bits so far: {''.join(str(b) for b in recovered_bits)}")

            unfixed_L_bits = new_L_bits[num_fixed:] if num_fixed < self.precision else []
            unfixed_H_bits = new_H_bits[num_fixed:] if num_fixed < self.precision else []
            new_L_bits_updated = unfixed_L_bits + [0] * num_fixed
            new_H_bits_updated = unfixed_H_bits + [1] * num_fixed
            L = bits2int(new_L_bits_updated)
            H = bits2int(new_H_bits_updated) + 1
            # print(f"Updated interval for next step: [{L}, {H})")

            token_tensor = torch.tensor([[token_id]], device=self.device)
            output_ids = torch.cat([output_ids, token_tensor], dim=-1)

        # print(f"\nFinal recovered secret bits: {''.join(str(b) for b in recovered_bits)}")
        return recovered_bits


def text_to_binary(text: str) -> list:
    """Convert text to a list of bits (as integers)."""
    return [int(bit) for char in text for bit in format(ord(char), '08b')]


def bits_to_text(bits: list) -> str:
    """Convert a list of bits to text (8 bits per character)."""
    chars = []
    for i in range(0, len(bits), 8):
        byte_bits = bits[i:i + 8]
        if len(byte_bits) < 8:
            break
        byte_str = ''.join(str(bit) for bit in byte_bits)
        chars.append(chr(int(byte_str, 2)))
    return ''.join(chars)


if __name__ == "__main__":
    # Load GPT-2 model and tokenizer.
    from global_var import path
    tokenizer = GPT2Tokenizer.from_pretrained(path)
    model = GPT2LMHeadModel.from_pretrained(path)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    # Create an instance of ArithmeticSteganography with integer-based arithmetic.
    stego = ArithmeticSteganography(model, tokenizer, device=device, precision=32, top_k=300)

    # Example secret message.
    secret_text = "Hello World!"
    secret_text = "here we report that cell surface sialic acid plays an important role in zikv infection."
    message_bits = text_to_binary(secret_text)
    prompt = "When I walked into a bar,"

    print("=== ENCODING ===")
    cover_text, cover_ids, bpw, ppl = stego.encode(message_bits, prompt)
    print("\nFinal Cover text:", cover_text)

    # print("\n=== DECODING ===")
    # recovered_bits = stego.decode(cover_ids, prompt)
    # recovered_text = bits_to_text(recovered_bits)
    # print("\nRecovered text:", recovered_text)
    print("BPW:", bpw)
    print("Perplexity: ", ppl)