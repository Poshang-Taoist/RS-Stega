import torch
import torch.nn.functional as F
import heapq
from typing import List
import numpy as np
from global_var import path

class HuffmanNode:
    """
    A simple Huffman Tree node.
    If 'token' is not None, it's a leaf node mapping to a particular token index.
    Otherwise, it's an internal node with 'left'/'right' children.
    """
    __slots__ = ['freq', 'token', 'left', 'right']

    def __init__(self, freq, token=None):
        self.freq = freq  # Probability or frequency
        self.token = token  # Token index if leaf; otherwise None
        self.left = None
        self.right = None

    def __lt__(self, other):
        return self.freq < other.freq


class HuffmanCoding:
    """
    Builds a Huffman tree and associated bit codes, given a list of probabilities.
    """

    def __init__(self):
        self.heap = []
        self.codes = {}
        self.root = None

    def make_heap_from_array(self, probs_array):
        """
        Build a min-heap of HuffmanNodes from the given probabilities array.
        Each index in 'probs_array' corresponds to a token candidate.
        """
        for idx, p in enumerate(probs_array):
            node = HuffmanNode(freq=p, token=idx)
            self.heap.append(node)
        heapq.heapify(self.heap)

    def merge_nodes(self):
        """
        Merge the smallest two nodes until we get a single root.
        """
        while len(self.heap) > 1:
            left = heapq.heappop(self.heap)
            right = heapq.heappop(self.heap)
            merged = HuffmanNode(freq=left.freq + right.freq)
            merged.left = left
            merged.right = right
            heapq.heappush(self.heap, merged)
        self.root = self.heap[0] if self.heap else None

    def make_codes(self):
        """
        Create a dictionary { index_in_probs_array -> bitstring } by traversing the Huffman tree.
        """

        def traverse(node, current_bits):
            if node is None:
                return
            if node.token is not None:
                self.codes[node.token] = current_bits
                return
            traverse(node.left, current_bits + "0")
            traverse(node.right, current_bits + "1")

        if self.root is not None:
            traverse(self.root, "")


class HuffmanSteganography:
    """
    Huffman-based steganography using a language model.
    """

    def __init__(self, model, tokenizer, bits_per_word: int, device: str = 'cuda'):
        self.model = model.to(device)
        self.tokenizer = tokenizer
        self.bits_per_word = bits_per_word
        self.device = device
        self.log_list = [] 

    def encode(self, message_bits: List[int], prompt: str) -> (str, List[int]):

        input_ids = torch.tensor(self.tokenizer.encode(prompt), device=self.device).unsqueeze(0)
        output_ids = input_ids.clone()
        pointer = 0
        cnt = 0
        while pointer < len(message_bits):
            with torch.no_grad():
                outputs = self.model(output_ids)
                logits = outputs.logits[:, -1, :]  # shape: (1, vocab_size)

            # Restrict to top 2^bits_per_word tokens
            top_k = 2 ** self.bits_per_word
            top_logits, top_indices = torch.topk(logits, k=top_k, dim=-1)
            log_probs = F.log_softmax(top_logits, dim=-1)
            probs = torch.exp(log_probs).squeeze(0).cpu().numpy()

            # Build Huffman tthreshold
            coder = HuffmanCoding()
            coder.make_heap_from_array(probs)
            coder.merge_nodes()
            coder.make_codes()

            # Traverse the Huffman tree using bits from 'message_bits'
            node = coder.root
            while node.token is None and pointer < len(message_bits):
                bit = message_bits[pointer]
                pointer += 1
                if bit == 0:
                    node = node.left
                else:
                    node = node.right

            # If we reach a leaf node, 'token' is the index in top-k
            if node and node.token is not None:
                chosen_rank = node.token
            else:
                chosen_rank = 0  # fallback if something goes wrong

            chosen_id = top_indices[0, chosen_rank].unsqueeze(0).unsqueeze(0)
            #记录生成的token的probability到log_list中
            chosen_prob = probs[chosen_rank]  # 取出对应 token 的概率
            self.log_list.append(chosen_prob)
            output_ids = torch.cat([output_ids, chosen_id], dim=-1)
            cnt += 1

        ppl = self.calculate_ppl()
        bpw = self.calculate_bpw(len(message_bits), cnt)
        cover_text = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
        return cover_text, output_ids[0].tolist(), ppl, bpw

    def calculate_ppl(self):
        log_probs = np.log(self.log_list)  # 取对数
        avg_log_prob = np.mean(log_probs)  # 计算平均 log 概率
        ppl = np.exp(-avg_log_prob)  # 计算 PPL
        return ppl
    
    def calculate_bpw(self, num_bits, num_generated_tokens):
        bpw = num_bits / num_generated_tokens if num_generated_tokens > 0 else 0
        return bpw
    
    def decode(self, cover_ids: List[int], prompt: str, max_bits=10_000) -> List[int]:
        """
        Decode the binary message from the given text by reconstructing Huffman trees at each step.

        Args:
            cover_ids: The list of tokens (including the prompt).
            prompt: The same initial prompt used during encoding.
            max_bits: Safety limit on how many bits we'll decode.

        Returns:
            decoded_bits: The recovered bits from the Huffman-coded tokens.
        """
        input_ids = self.tokenizer.encode(prompt)
        # The newly generated tokens are everything after the prompt
        generated_ids = cover_ids[len(input_ids):]

        output_ids = torch.tensor(input_ids, device=self.device).unsqueeze(0)
        decoded_bits = []
        pointer = 0

        for token_id in generated_ids:
            with torch.no_grad():
                outputs = self.model(output_ids)
                logits = outputs.logits[:, -1, :]

            top_k = 2 ** self.bits_per_word
            top_logits, top_indices = torch.topk(logits, k=top_k, dim=-1)
            log_probs = F.log_softmax(top_logits, dim=-1)
            probs = torch.exp(log_probs).squeeze(0).cpu().numpy()

            # Build Huffman tree
            coder = HuffmanCoding()
            coder.make_heap_from_array(probs)
            coder.merge_nodes()
            coder.make_codes()

            # Figure out which rank the actual 'token_id' has among top_k
            # If it's not in top_k, fallback to rank=0
            try:
                rank = (top_indices[0] == token_id).nonzero().item()
            except:
                rank = 0

            # The Huffman code for 'rank' is a string, e.g. '010'
            code_str = coder.codes.get(rank, "")
            for bit_char in code_str:
                if len(decoded_bits) < max_bits:
                    decoded_bits.append(int(bit_char))

            # Move to next step
            chosen_id = torch.tensor([[token_id]], device=self.device)
            output_ids = torch.cat([output_ids, chosen_id], dim=-1)

        return decoded_bits


def text_to_binary(text: str) -> List[int]:
    return [int(bit) for char in text for bit in format(ord(char), '08b')]


def bits_to_text(bits: List[int]) -> str:
    chars = []
    for i in range(0, len(bits), 8):
        byte_bits = bits[i:i + 8]
        if len(byte_bits) < 8:
            break
        byte_str = ''.join(str(bit) for bit in byte_bits)
        chars.append(chr(int(byte_str, 2)))
    return ''.join(chars)

if __name__ == "__main__":
    from transformers import GPT2LMHeadModel, GPT2Tokenizer

    tokenizer = GPT2Tokenizer.from_pretrained(path)
    model = GPT2LMHeadModel.from_pretrained(path)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    stego = HuffmanSteganography(model, tokenizer, bits_per_word=16, device=device)

    secret_text = "anytime anywhere raw cold ice top quality no stuff arounds 200 half g 350 a g feel free and welcome, you do right by us and we'll always do right by you no doubt about that so feel free to email me and get this sorted."
    prompt = "When I walk into a bar"
    message_bits = text_to_binary(secret_text)

    cover_text, cover_ids, ppl, bpw = stego.encode(message_bits, prompt)
    print("Cover text:", cover_text)

    # recovered_bits = stego.decode(cover_ids, prompt)
    # recovered_text = bits_to_text(recovered_bits)
    # print("Recovered text:", recovered_text)
    print("BPW:", bpw)
    print("Perplexity: ", ppl)
