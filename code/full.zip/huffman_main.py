from huffamn_baseline import HuffmanSteganography
from huffman_reject import HuffmanSteganography as HuffmanRejectSteganography
from huffman_split import HuffmanSteganography as HuffmanSplitSteganography
from huffman_full import HuffmanSteganography as HuffmanFullSteganography
from global_var import path
import numpy as np
import torch
import random
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import csv
from datetime import datetime

def load_messages_from_txt(txt_file):
    """从 TXT 文件读取消息，每行一个元素，超出 max_length 部分截断"""
    messages = []
    with open(txt_file, 'r', encoding='utf-8') as file:
        for line in file:
            message = line.strip()  # 去掉首尾空格和换行符
            if message:  # 确保不是空行
                messages.append(message)  # 截断超长文本
    return messages

def test_single(**kwargs):
    # Access the parameters
    context = kwargs.get("context", "By now, many Americans are used to hearing")
    message = kwargs.get("message", "Hello, Steganography World!!") #Original Message/Plaintext
    threshold = kwargs.get("threshold", 100)
    method = kwargs.get("method", "bin")
    block_size = kwargs.get("block_size", 2)
    model = kwargs.get("model", -1)
    tokenizer = kwargs.get("tokenizer", -1)
    device = kwargs.get("device", "cpu")

    # Convert the message into a binary format
    binary_message = []
    for char in message:
        binary_message.extend(list(map(int, bin(ord(char))[2:].zfill(8))))  # Convert each char to 8-bit binary

    divisible_length = (len(binary_message) // (block_size // 2)) * (block_size * 2)
    # Slice the list to the divisible length
    binary_message = binary_message[:divisible_length]
    if method=='huff':
        stego = HuffmanSteganography(model, tokenizer, bits_per_word=block_size, device=device)
        cover_text, cover_ids, ppl, bpw = stego.encode(binary_message, context)
    elif method=='rejecthuff':
        stego = HuffmanRejectSteganography(model, tokenizer, bits_per_word=block_size, threshold=threshold, device=device)
        cover_text, cover_ids, ppl, bpw = stego.encode(binary_message, context)
    elif method=='splithuff':
        stego = HuffmanSplitSteganography(model, tokenizer, bits_per_word=block_size, device=device)
        cover_text, cover_ids, ppl, bpw = stego.encode(binary_message, context)
    elif method == 'fullhuff':
        stego = HuffmanFullSteganography(model, tokenizer, bits_per_word=block_size, device=device, threshold=threshold)
        cover_text, cover_ids, ppl, bpw = stego.encode(binary_message, context)
    return cover_text, bpw, ppl

import argparse
def parse_args():
    parser = argparse.ArgumentParser(description="Run GPT-2 text steganography experiment.")
    # parser.add_argument("--block_size", type=int, default=4, help="MAX_BLOCK_SIZE")
    parser.add_argument("--method", type=str, default="huff", help="Steganography method to use.")
    # parser.add_argument("--threshold", type=int, default=10, help="Reject threshold")
    return parser.parse_args()
#nohup python -u huffman_main.py --method "huff" > huff1216.log 2>&1 &
#nohup python -u huffman_main.py --method "rejecthuff" > rej60huff8.log 2>&1 &
# nohup python -u huffman_main.py --method "splithuff"> splithuff681012.log 2>&1 &
# nohup python -u huffman_main.py --method "fullhuff"> full30huff81012.log 2>&1 &
# echo "cd /home/ubuntu/stega/reject && nohup python -u randompath2.py > random8reject.log 2>&1" | at now + 6 hours
if __name__ == '__main__':
    args = parse_args()
    print(f"Running {args.method}")
    seed = 1234
    np.random.seed(seed)
    random.seed(seed)
    torch.random.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    # Load the language model and tokenizer
    model = GPT2LMHeadModel.from_pretrained(path)
    tokenizer = GPT2Tokenizer.from_pretrained(path)
    model.eval()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # device = torch.device("cpu")
    model.to(device)
    print(f"Model loaded to {device} successfully.")

    method = args.method
    # threshold = args.threshold
    
    dataset_path="../datasets"
    for threshold in [60]:
        for block_size in [8]:#6,10,128,,10,12
            print(f"Starting block{block_size} process...")
            for dataset_name in ["druge","newse","covide"]:
                txt_file = f"{dataset_path}/{dataset_name}.txt"
                messages = load_messages_from_txt(txt_file)
                tot = len(messages)
                cnt = 0
                print(f"Starting the process...")
                timestamp_str = datetime.now().strftime("%Y%m%d%H%M%S")
                print(timestamp_str)  # 示例输出: 20250315123045
                # 指定 CSV 文件路径
                csv_file = f"./result/{dataset_name}_{block_size}_{method}_thres{threshold}_{timestamp_str}.csv"  
                # 先写入 CSV 头部
                with open(csv_file, "w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)
                    writer.writerow(["id", "message", "length", "bpw", "ppl", "covertext"])  # 写入表头
                
                for m in messages:
                    cnt += 1
                    # if cnt<101:#dataset_name=="covid450" and 
                        # print(f"skip{cnt}")
                        # continue
                    timest = datetime.now().strftime("%d-%H:%M:%S")
                    print(f"Processing {dataset_name} [{cnt}/{tot}]@{timest}")
                    params = {
                        "model": model,
                        "tokenizer": tokenizer,
                        "device": device,
                        "context": "When I walked into a bar,",
                        "message": m,
                        "threshold": threshold,
                        "method": method,
                        "block_size": block_size
                    }

                    # Call the function using **kwargs
                    covertxt, bpw, ppl = test_single(**params)
                    
                    with open(csv_file, "a", newline="", encoding="utf-8") as f:
                        writer = csv.writer(f)
                        writer.writerow([cnt, m, len(m), bpw, ppl, covertxt])
                print(f"\nResults saved to {csv_file}")