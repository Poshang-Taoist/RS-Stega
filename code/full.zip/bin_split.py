import torch
import torch.nn.functional as F
import numpy as np
from typing import List
from global_var import path

class StaticBinSteganography:
    """
    Minimal static bin-based steganography approach.

    Attributes:
        model: A (language) model from Hugging Face Transformers.
        tokenizer: The corresponding tokenizer.
        block_size: The number of bits we encode per token.
        device: 'cpu' or 'cuda'.
        bin2words: A dict mapping bin indices -> list of token IDs.
        words2bin: A dict mapping token IDs -> bin index.
    """

    def __init__(self, model, tokenizer, block_size: int, device: str = 'cuda', seed: int = 1234):
        self.model = model.to(device)
        self.tokenizer = tokenizer
        self.block_size = block_size
        self.device = device
        self.bin2words, self.words2bin = self._generate_bins(tokenizer, block_size//2, seed)
        self.all_log_list = [] 

    def _generate_bins(self, tokenizer, block_size: int, seed: int):
        """
        Shuffle the vocabulary and split it into 2^block_size bins.
        Returns:
            bin2words: dict of { bin_index: [token_id1, token_id2, ...] }
            words2bin: dict of { token_id: bin_index }
        """
        vocab_size = tokenizer.vocab_size
        all_token_ids = np.arange(vocab_size)
        np.random.seed(seed)
        np.random.shuffle(all_token_ids)

        num_bins = 2 ** block_size
        bin_size = vocab_size // num_bins

        bin2words = {}
        words2bin = {}

        for i in range(num_bins):
            start = i * bin_size
            end = (i + 1) * bin_size if i < num_bins - 1 else vocab_size
            bin_tokens = all_token_ids[start:end]
            bin2words[i] = bin_tokens.tolist()
            for tid in bin_tokens:
                words2bin[tid] = i

        return bin2words, words2bin

    def encode(self, message_bits: List[int], prompt: str) -> str:
        input_ids = torch.tensor(self.tokenizer.encode(prompt), device=self.device).unsqueeze(0)
        output_ids = input_ids.clone()
        prev_ids = input_ids.clone()
        pointer = 0

        # 记录 KL 计算所需的分布
        original_probs_list = []
        stego_probs_list = []
        cnt = 0
        with torch.no_grad():
            while pointer < len(message_bits):
                bits_chunk = message_bits[pointer:pointer + self.block_size//2]
                binary_str = ''.join(map(str, bits_chunk))
                k = int(binary_str, 2)
                outputs = self.model(prev_ids)
                outputs.logits[0, -1, -1] = -1e10  # endoftext can't happen
                outputs.logits[0, -1, 628] = -1e10  # 2 newlines can't happen
                logits = outputs.logits[:, -1, :]
                

                original_probs = F.softmax(logits, dim=-1)
                
                original_probs_list.append(original_probs)

                filtered_logits = torch.full_like(logits, float('-inf'))
                bin_tokens = self.bin2words[k]
                filtered_logits[0, bin_tokens] = logits[0, bin_tokens]

                chosen_id = torch.argmax(filtered_logits, dim=-1)
                self.all_log_list.append(original_probs[0,chosen_id.item()].item())
                chosen_id = chosen_id.unsqueeze(-1)
                

                output_ids = torch.cat([output_ids, chosen_id], dim=-1)
                prev_ids = output_ids[-256:]
                pointer += self.block_size//2
                cnt += 1

        cover_text = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
        cover_ids = output_ids[0].tolist()

        ppl = self.calculate_ppl()
        bpw = self.calculate_bpw(len(message_bits), cnt)
        return cover_text, cover_ids, ppl, bpw
    
    def calculate_ppl(self):
        log_probs = np.log(self.all_log_list)  # 取对数
        avg_log_prob = np.mean(log_probs)  # 计算平均 log 概率
        ppl = np.exp(-avg_log_prob)  # 计算 PPL
        return ppl
    def calculate_bpw(self, num_bits, num_generated_tokens):
        bpw = num_bits / num_generated_tokens if num_generated_tokens > 0 else 0
        return bpw

    def decode(self, cover_text: str, cover_ids, prompt: str) -> List[int]:
        input_ids = self.tokenizer.encode(prompt)
        encoded_ids = cover_ids[len(input_ids):]
        decoded_bits = []

        for token_id in encoded_ids:
            bin_index = self.words2bin.get(token_id, 0)
            bin_str = bin(bin_index)[2:].zfill(self.block_size)
            for bit_char in bin_str:
                decoded_bits.append(int(bit_char))

        return decoded_bits


def text_to_binary(text):
    """
    Convert a text string into its binary representation (8 bits per character).
    """
    return ''.join(format(ord(char), '08b') for char in text)


def bits_to_text(bits):
    """
    Convert a list of bits into a text string, interpreting every 8 bits as one character.
    """
    chars = []
    for i in range(0, len(bits), 8):
        byte_bits = bits[i:i + 8]
        byte_str = ''.join(str(bit) for bit in byte_bits)
        chars.append(chr(int(byte_str, 2)))
    return ''.join(chars)



if __name__ == "__main__":
    from transformers import GPT2LMHeadModel, GPT2Tokenizer
    
    tokenizer = GPT2Tokenizer.from_pretrained(path)
    model = GPT2LMHeadModel.from_pretrained(path)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    stego = StaticBinSteganography(model, tokenizer, block_size=4, device=device)

    message_bits = text_to_binary("Hello World! Txchis is a test mess^*age.")#anytime anywhere raw cold ice top quality no stuff arounds 200 half g 350 a g feel free and welcome, you do right by us and we'll always do right by you no doubt about that so feel free to email me and get this sorted.'Hello World! Txchis is a test mess^*age.'
    prompt = "When I walk into a bar"
    print("Message bits length:", len(message_bits))
    cover_text, cover_ids, ppl, bpw = stego.encode(message_bits, prompt)
    print("Cover length:", len(cover_ids))
    print("Cover text:", cover_text)


    # decoded_bits = stego.decode(cover_text, cover_ids, prompt)
    # print("Decoded bits:", decoded_bits)
    # print("Decoded text:", bits_to_text(decoded_bits))
    print("BPW:", bpw)
    print("Perplexity: ", ppl)