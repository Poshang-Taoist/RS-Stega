from openai import OpenAI
import pandas as pd
import time
import os
import re
from openpyxl import load_workbook

# 配置 OpenAI API
api_key = "sk-r3LmdrlYFDsJYJIoMKd6CK7UX17qNyjGPzmLQme7JGGfYKSL"
api_base = "https://sg.uiuiapi.com/v1"

client = OpenAI(api_key=api_key, base_url=api_base)

# **评分函数**
def score_covertext(text):
    prompt = (
    "请扮演一位隐写术专家，根据以下标准对文本进行综合评分（1-10）：\n"
    "1. 隐写容量与文本质量平衡：文本在嵌入秘密信息时是否保持了自然、流畅且不引起异常。\n"
    "2. 语法正确性与语义连贯性：文本是否符合自然语言表达习惯，逻辑是否连贯。\n"
    "3. 隐蔽性：文本表面是否与普通文本无异，是否能有效隐藏秘密信息而不被察觉或不被怀疑。\n"
    "4. 自适应性：文本是否能根据上下文灵活调整表达，达到最佳隐写效果。\n\n"
    "请基于上述标准仅返回一个数字，其中10表示各项均表现出色；不要附加任何解释。\n\n"
    f"{text}\n\n"
    "评分："
    )

    attempt = 0
    while attempt < 3:  # 最多尝试 5 次nohup python -u gpt.py > rank.log 2>&1 &
        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "你是一个隐写术专家，负责评估隐写文本质量。"},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=5,
                temperature=0.3
            )

            content = response.choices[0].message.content.strip()
            score_match = re.search(r"\b([1-9]|10)\b", content)

            if score_match:
                return int(score_match.group(1))
            else:
                print(f"⚠️ 无法解析 GPT 返回的评分: {content}")
                return None

        except Exception as e:
            attempt += 1
            print(f"❌ 评分失败，第 {attempt} 次重试。错误信息：{e}")
            time.sleep(3)  # 等待 2 秒后重试

    print(f"⚠️ 评分失败，已尝试 5 次，跳过此项。")
    return None


# **封装评分处理函数**
def process_csv_file(input_file):
    output_file = f"out_{os.path.basename(input_file).replace('.csv', '')}.xlsx"
  # 输出文件名：out+原始文件名.xlsx
    
    # 读取 CSV 文件
    df = pd.read_csv(input_file)
    df["id"] = pd.to_numeric(df["id"], errors="coerce").fillna(-1).astype(int)

    # 确保存在必要的列
    if "id" not in df.columns or "covertext" not in df.columns:
        print(f"❌ {input_file} 缺少 'id' 或 'covertext' 列，跳过处理！")
        return

    # **检查已评分数据，避免重复评分**
    if os.path.exists(output_file):
        existing_df = pd.read_excel(output_file)
        scored_ids = set(existing_df["id"])
    else:
        scored_ids = set()
        pd.DataFrame(columns=["id", "covertext", "score"]).to_excel(output_file, index=False)  # 创建新文件

    # **逐行评分，并实时写入 Excel**
    for index, row in df.iterrows():
        if row["id"] in scored_ids:
            print(f"跳过已评分 ID: {row['id']} ({input_file})")
            continue

        print(f"正在评分 ID: {row['id']} ({input_file})...")
        score = score_covertext(row["covertext"])

        if score is not None:
            # **将新评分写入 Excel**
            new_row = pd.DataFrame([[row["id"], row["covertext"], score]], columns=["id", "covertext", "score"])
            
            with pd.ExcelWriter(output_file, mode="a", engine="openpyxl", if_sheet_exists="overlay") as writer:
                new_row.to_excel(writer, index=False, header=False, startrow=writer.sheets["Sheet1"].max_row)

            print(f"✅ ID {row['id']} 评分为 {score} ({input_file})")
        else:
            print(f"❌ ID {row['id']} 评分失败，稍后可重试。 ({input_file})")

        time.sleep(1)  # 避免 API 速率限制

    print(f"🎉 处理完成：{input_file} -> {output_file}")


# **主函数：批量处理目录下所有 CSV 文件**
def main(input_dir):
    # 获取目录下所有 CSV 文件
    csv_files = [f for f in os.listdir(input_dir) if f.endswith(".csv")]

    if not csv_files:
        print("⚠️ 目录中没有找到 CSV 文件！")
        return

    print(f"📂 在 {input_dir} 目录中找到 {len(csv_files)} 个 CSV 文件，开始处理...")

    for file in csv_files:
        file_path = os.path.join(input_dir, file)
        process_csv_file(file_path)  # 逐个处理 CSV 文件

    print("✅ 所有文件处理完成！")

# **运行主程序**
if __name__ == "__main__":
    input_directory = "./"  # 指定 CSV 文件所在目录（当前目录）
    main(input_directory)
